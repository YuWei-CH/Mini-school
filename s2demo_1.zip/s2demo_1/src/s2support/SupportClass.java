/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s2support;

/**
 *
 * @author victo
 */
public class SupportClass {
    
    public final static String SCN = "AAA";
    
    public final int length;
   final int CONS ;
    String name;
    int age;
    
    public SupportClass(int age, String name, int length)
    {
       this.name = name;
       this.age = age;
       this.length = length;
       
       if(age > 10)
           CONS = 3;
       else
           CONS =4;           
    }
 
    public void setCONS(int a)
    {
      
        //System.out.print(SCN);       
    }
    
    /* this method intends to change the school name 
        and it has to use the static variable SCN
*/
    public static String getSCN()
    {
      return SCN;
    }
           
    
    
}
