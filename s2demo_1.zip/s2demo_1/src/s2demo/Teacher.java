/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s2demo;

import java.util.ArrayList;

/**
 *
 * @author victo
 */
public class Teacher {
    
    private String name;
    private ArrayList<Course> cList = new ArrayList<Course>();
    private String group;
    
    
    public Teacher(String name, Course course,String group)
    {
        this.name = name;
        this.group = group;
        this.cList.add(course);
//        if(course.getTeacher()!=null)
//            {   course.setT(this);
//                }
//        else
//        {
//            System.out.print("this course already has a teacher assing to it");
//        }
      
    }
    //    
//    public Teacher(String name, Course c1, Course c2, String group)
//    {
//        this.name = name;
//        this.group = group;
//        this.cList.add(c1);
//        c1.setT(this);
//        this.cList.add(c2);
//        c2.setTeacher(this);
//    }
    public void addCourse(Course course)
    {
        cList.add(course);
    }
    
    public void showCourseList()
    {
        System.out.println(cList);
    }
    
    public String toString()
    {
        return name;
    }
    

    
}
