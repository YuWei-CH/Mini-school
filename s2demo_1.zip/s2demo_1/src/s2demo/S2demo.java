/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s2demo;
;

/**
 *
 * @author victo
 */

import java.util.ArrayList;
import java.util.Scanner;
import s2support.SupportClass;
import s2support.sub.s2;

public class S2demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
//        Student s1 = new Student("pepper",false,"AP"); 
//        Student s2 = new Student("jackie",false,"AL");
//        Student s3 = new Student("mike",false,"AP");
//        Student s4 = new Student("siri",false,"AP");
//        Student s5 = new Student("pepper",false,"AP");
        
        
        //Student s6 = new Student();
        
        
        Course csa = new Course("CSA","AP",10);  
        double score =5.0;
        
        System.out.println(csa.getScore(score));
        System.out.print(score);
        Course csb = new Course("CSB","AL",10);
        Course csc = new Course("CSC","AP",10);
        Course csd = new Course("CSD","AL",12);
       // System.err.print(csa.getTeacher());
      //  Teacher zzc = new Teacher("zzc",csb,"sicence");
        
      //  System.out.print(csb.getTeacher());
//        zzc.addCourse(csd);
//        s1.upGrade();
//        s3.upGrade();
//      s1.addCourse(csa);
//        s3.addCourse(csa);
//       s5.addCourse(csa);
//        //s3.addCourse(csa);
//        // s4.addCourse(csa);
//      //  s1.showSelectedCourses();
//        //zzc.showCourseList();
//       csa.showStudentList();
//         

           // System.out.print(csa.getTeacher() );
        
        
        
       
        
      //  System.out.print(s1.getType().equals(csa.getType()));
        
        
        
        
        
 
        
    }
    

  
}









