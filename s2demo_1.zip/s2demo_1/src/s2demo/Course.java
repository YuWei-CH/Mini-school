/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s2demo;

import java.util.ArrayList;

/**
 *
 * @author victo
 */
public class Course {
    
    public String name;
    private String type;
    private Teacher teacher;
    public final static int MAX_STUDENTS = 4;
    public int studentNum;
    private int reqGrade;
    private double score;
    private ArrayList<Student> sList  = new ArrayList<Student>();
    
    
    
    public Course(String name, String type, int ReqGrade)
    {
        this.name = name;
        this.type = type;
        score = 5.0;
        this.reqGrade = ReqGrade;
        studentNum = 0 ;
    }
    
    
    
    public String getName()
    {
        return name;
    }
    
    
    public double getScore(double mark)
    {
        if(this.type.equals("AP"))
        {   mark*=0.8;
            return mark;
        }
        else
            return mark;
    }
    

    public String getType()
    {
        return type;
    }
    
    public void setT(Teacher t)
    {
        teacher = t;
    }
    public Teacher getTeacher()
    {
        return teacher;
    }
    
    
    public double getScore()
    {
        return score;
    }   
            
    
    public int getSNUM()
    {
        return studentNum;
    }
    
    
    public int getReqGrade()
    {
        return reqGrade;
    }
    
    public void increSNUM()
    {
        studentNum++;
    }
    public String toString()
    {
        return "course name : "+name + "  course type: "+ type + " course score: "+ score;
    }
    
    
    public void showStudentList()
    {
       for(Student s : sList)
       {
           System.out.print(s.getName()+" "+s.getGrade()+",");
       }
    }
    
    public void showStudentList(int grade)
    {
        for(Student s : sList)
        {
            if(s.getGrade() == grade)
            {
                System.out.print(s.getName()+",");
            }
        }
        
    }
    
    public void showStudentList(boolean isStay)
    {
        for(Student s : sList)
        {
            if(s.isStay() == isStay)
            {
                System.out.print(s.getName()+",");
            }
        }
    }
    
    public void addStudent(Student s)
    {
        sList.add(s);
    }
}
