/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s2demo;

import java.util.ArrayList;

/**
 *
 * @author victo
 */
public class Student {
 // class attributes   
    private int grade;
    private String name;
    private boolean Stay;
    private String type;
    private static int ID = 2018001;
    private int sid;
    
    private ArrayList<Course> clist;
    public static final int MAX_COURSE_ALLOWED =6;
// constuctor


public Student(String name, boolean s, String type)
{
    clist = new ArrayList<Course>();
    sid = ID;
    grade = 10;
    this.name = name;
    this.type = type;
    Stay = s;
    ID++;
}

public Student(String name, boolean s, String type, int grade)
{
    this(name,s,type);   //super();
    this.grade = grade;
}


    
// methods
    // accessor
    public int getGrade()
    {
        return grade;
    }
    
    public String getName()
    {
        return name;
    }
        
    public boolean isStay()
    {
        return Stay;
    }
    
    public int getID()
    {
        return sid;
    }
    
    //mutator
    
    public void upGrade()
    {
        this.grade++;
    }
    
    public void changeStatus()
    {
       Stay = !Stay;
    }
   
    public String getType()
    {
        return type;
    }
    // for students to add their personal courses
    
    public void addCourse(Course course)
    {
        
       
        
        if(clist.size()<MAX_COURSE_ALLOWED&&clist.contains(course)!=true)
        {
           if(course.getSNUM()<Course.MAX_STUDENTS)
           {
                if(this.type.equals(course.getType())&&this.grade>=course.getReqGrade())
                {   clist.add(course);
                    course.increSNUM();
                    course.addStudent(this);
                    System.out.println("the course: "+ course.getName()+" has been addded successfully to " + this.name);
                }
                else
                {
                    System.out.println("fail to add the course, please check your grade or type");
                }
           }
           else
           {
               System.out.print("fail to enroll, too many students");
           }
               

        }
        else
            System.out.println("fail to add course, you have already enrolled enough courses or you have already added this course");
        
    }
    
    
    public ArrayList<Course> getCList()
    {
        return clist;
    }
    
    
    public void showCourseList()
    {
        if(clist.size()!=0)
        {    System.out.println("the courses you have enrolled are:");

            for(Course c : clist)
            {
                System.out.println(c);
            }        
        }
        else
        {
            System.out.print("you haven't enrolled any course yet");
        }
    }
//    
//    public String toString()
//    {
//        return name + " " + grade;
//    }

}
